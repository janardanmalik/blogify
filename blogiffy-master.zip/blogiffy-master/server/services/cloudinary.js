const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "ddad6nzxk",
  api_key: "155371549231758",
  api_secret: "ZrzVTLmLSM4vSTNAAsHqjCwm2eA",
});

module.exports = cloudinary;
